package ShoppingCart;


public class ShoppingCartException extends Exception{
	public ShoppingCartException()
	{
		
	}
	
	public ShoppingCartException(String message){
		super(message);
	}
}
